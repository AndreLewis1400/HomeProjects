package Assignment_4_BinarySearchTree;

// Node class for Binary Search Tree
public class Node {
	
	int key;
	
	Node leftChild;
	Node rightChild;
	
	public Node(int key) {
		this.key = key;
		this.leftChild = null;
		this.rightChild = null;
	}
	
}
